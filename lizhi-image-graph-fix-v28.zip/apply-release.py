from pathlib import Path
import re,sys
root=Path.cwd();bundle=Path(__file__).resolve().parent
index=root/'index.html';html=index.read_text()
versions={}
for name in ('auth.js','app.js'):
 pattern=re.escape(name)+r'\?v=(\d+)';matches=re.findall(pattern,html)
 if len(matches)!=1:raise SystemExit('入口版本不明，已停止：'+name)
 versions[name]=int(matches[0])+1
 html=re.sub(pattern,lambda m:name+'?v='+str(versions[name]),html)
app=root/'app.js';source=app.read_text()
if 'function renderImageGraph()' not in source:raise SystemExit('找不到映構入口，已停止')
source,count=re.subn(r'(image-graph/\?v=)\d+',r'\g<1>28',source)
if count<1:raise SystemExit('找不到映構版本，已停止')
sw=root/'sw.js';worker=sw.read_text();start='  // BEGIN IMAGE GRAPH ASSETS';end='  // END IMAGE GRAPH ASSETS'
if worker.count(start)!=1 or worker.count(end)!=1:raise SystemExit('快取區段無法辨識，已停止')
worker=worker[:worker.index(start)]+(bundle/'cache-block.txt').read_text()+worker[worker.index(end)+len(end):]
worker,count=re.subn(r'(const CACHE="lizhi-cloud-v)(\d+)(";)',lambda m:m[1]+str(int(m[2])+1)+m[3],worker)
if count!=1:raise SystemExit('快取版本無法辨識，已停止')
for name,version in versions.items():worker=re.sub(r'(?<=")'+re.escape(name)+r'\?v=\d+',lambda m:name+'?v='+str(version),worker)
# Write only after every guard passes. Other modules and route edits stay intact.
index.write_text(html);app.write_text(source);sw.write_text(worker)
print('已保留目前主線功能，更新映構入口與快取版本。')
