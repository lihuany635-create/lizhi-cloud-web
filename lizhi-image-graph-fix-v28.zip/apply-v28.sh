#!/usr/bin/env bash
set -euo pipefail
bundle_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_dir="$(git rev-parse --show-toplevel)"
cd "$repo_dir"
if [[ "$(basename "$repo_dir")" != 'lizhi-cloud-web' ]]; then
  echo '請在 lizhi-cloud-web 專案的終端機執行。'; exit 1
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo '此專案有未提交的修改，已停止。請先保留修改，不會強制覆蓋。'; exit 1
fi
(cd "$bundle_dir" && sha256sum --check SHA256SUMS)
git fetch origin main
branch_name="fix/image-graph-v28-$(date +%Y%m%d%H%M%S)"
git switch -c "$branch_name" origin/main
git apply --exclude=app.js --exclude=index.html --exclude=sw.js --check "$bundle_dir/repair-v28.patch"
git apply --exclude=app.js --exclude=index.html --exclude=sw.js "$bundle_dir/repair-v28.patch"
python3 "$bundle_dir/apply-release.py"
node --check auth.js
node --check app.js
node --test scripts/test-image-graph-integration.mjs scripts/test-image-graph-auth.mjs
git diff --check
git add -- app.js auth.js image-graph index.html scripts/test-image-graph-integration.mjs scripts/test-image-graph-auth.mjs scripts/vendor-image-graph.mjs sw.js
git commit -m 'Fix Image Graph storage, task returns and mobile workflows v28'
if [[ "${1:-}" == '--prepare-only' ]]; then
  echo '更新與檢查完成，依 --prepare-only 未推送。'
else
  git push origin HEAD:main
  echo '已推送更新。請等待 GitHub Pages 部署完成，再重新整理雲端庫。'
fi
