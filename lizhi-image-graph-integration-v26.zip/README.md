# 映構整合到立之雲端庫 v26

狀態：整合程式與測試已完成；GitHub 拒絕寫入，因此雲端庫入口尚未上線。原映構及使用者資料保留。

## 已完成

- 雲端庫完整映構模組：專案、畫布、參考用途、裝置資料夾與多層新建、任務傳送/取消/刪除/復原、圖片回傳、驗收、另存與備份。
- 既有映構私人交接後端已發布，不複製登入憑證或將私人圖片提交到公開 repo。
- 原入口專案可一次接續並保留任務身分，不覆蓋現有目標；裝置資料夾需在新網址重新授權。

## 驗證

- 映構：332/332 通過；TypeScript 與正式建置通過。
- 雲端庫新增模組：3/3 通過，檔案完整性、快取資產及 iframe 狀態保留均檢查。
- 既有 Finance/Engineering：1317 項，1308 通過、9 項既有失敗；未修改基線與整合版失敗名稱一致。
- Patch 已在未修改基線執行 git apply --check 通過。
- 未驗證：手機跨來源登入視窗、休眠恢復與檔案選擇器實機行為。

## 發布阻擋

GitHub 的建立 tree 與建立 branch 都回覆 HTTP 403 Resource not accessible by integration。沒有更新遠端 main、沒有建立遠端分支或觸發 Pages 部署。不應把此包視為已上線版本。

目標 repo：https://github.com/lihuany635-create/lizhi-cloud-web
基線：3a412bbddbb7caf97be1641ecdb09a871f065af7
整合本機 commit：613199de9b3eaa15e1be5008c55e8c4dc31b9a6d
私人後端 commit：9ce006eb837d158632219e226427630d5a6fae88
私人後端：https://lizhi-image-graph.lihuany635.chatgpt.site

## 接續

恢復 GitHub 對上述 repo 的寫入授權後，可接續提交整合 commit，再由既有 main Pages workflow 發布。不要覆蓋本機尚未提交的 Phase 工作；若目標 HEAD 已變更，需先重新比對與解決衝突。

此包包含公開前端程式差異與說明，不包含使用者的圖檔、瀏覽器專案或原圖 handle。Patch 使用 Git 標準格式；先在目標 checkout 執行 git apply --check，再於獨立分支套用及驗證。
